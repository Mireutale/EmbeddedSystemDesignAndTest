/*
 * week11_advanced.c
 *
 *  Created on: 2023. 9. 4.
 *      Author: CYH
 *
 * Example of PWM motor operating in reverse according to button input
 */


#include "stm32f10x_adc.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_tim.h"
#include "misc.h"
#include "lcd.h"
#include "touch.h"
#include "math.h"

#define LCD_TEAM_NAME_X 20
#define LCD_TEAM_NAME_Y 50
#define LCD_STATUS_X 20
#define LCD_STATUS_Y 70

#define LCD_BUTTON_X    30
#define LCD_BUTTON_Y    100
#define LCD_BUTTON_W    50
#define LCD_BUTTON_H    50

void Init(void);
void RccInit(void);
void GpioInit(void);
void TIM_Configure(void);
void NvicInit(void);
void ledToggle(int num);

const int color[12] = { WHITE,CYAN,BLUE,RED,MAGENTA,LGRAY,GREEN,YELLOW,BROWN,BRRED,GRAY };

// timer counter
int t1;
int t2;
// led on/off
char ledOn;
// motor set
TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
TIM_OCInitTypeDef  TIM_OCInitStructure;
// motor angle
int motorAngle = 0;
int motorDir = 0;

int main() {
    uint16_t pos_x, pos_y;
    uint16_t pix_x, pix_y;

    Init();

    LCD_Clear(WHITE);

    // TODO: Display team name and button on LCD


    // TODO: Motor setup
    while (1) {
        if (ledOn == 0) {

        }
        else {

        }

        // Get touch position


        // Detect button touch
        if () {

        }
    }
}


void Init(void) {
    SystemInit();
    RccInit();
    GpioInit();
    TIM_Configure();
    NvicInit();

    LCD_Init();
    Touch_Configuration();
    Touch_Adjust();
}


void RccInit(void) {
    RCC_APB1PeriphClockCmd(RCC_APB1ENR_TIM2EN, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
}

// TODO
void GpioInit(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    uint16_t prescale = 0;
    // LED setup

    // PWM motor setup

    // Timer setup

}

// TODO
void TIM_Configure(void)
{

}

void NvicInit(void) {
    NVIC_InitTypeDef NVIC_InitStructure;

    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void ledToggle(int num) {
    uint16_t pin;

    switch (num) {
    case 1:
        pin = GPIO_Pin_2;
        break;
    case 2:
        pin = GPIO_Pin_3;
        break;
    case 3:
        pin = GPIO_Pin_4;
        break;
    case 4:
        pin = GPIO_Pin_7;
        break;
    default:
        return;
    }

    if (GPIO_ReadOutputDataBit(GPIOD, pin) == Bit_RESET) {
        GPIO_SetBits(GPIOD, pin);
    }
    else {
        GPIO_ResetBits(GPIOD, pin);
    }
}

void moveMotor() {
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = motorAngle + 700;
    if (motorDir == 0) {
        motorAngle = motorAngle + 100;
        if (motorAngle == 1500) motorAngle = 0;
    }
    else {
        motorAngle = motorAngle - 100;
        if (motorAngle == 0) motorAngle = 1500;
    }

    TIM_OC3Init(TIM3, &TIM_OCInitStructure);
}

/*
 * ISR
 */

void TIM2_IRQHandler(void) {
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) {

        t1++;
        t2++;
        moveMotor();

        if (ledOn == 1) {
            // Toggle LED 1
            ledToggle(1);
            if (t1 % 5 == 0) {
                // Toggle LED 2
                ledToggle(2);
            }
        }

        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    }
}
