
import bleManager from "./modules/serialManager.js";