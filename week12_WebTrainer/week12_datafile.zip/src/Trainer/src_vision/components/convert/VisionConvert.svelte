<script>
        import { Link } from "svelte-routing";
        
        import icArrowBlack from "@assets/img/ic_arrow_black.svg";
    import icArrowWhite from "@assets/img/ic_arrow_white.svg";
    import { onMount } from "svelte";
    import arrowRight from "@assets/icons/arrow_right.png";
    import TrainerConvert from "../../../components/common/TrainerConvert.svelte";
    // import { pushPropmt } from "../src_motion/stores/ui/actions";
    import { trainedModel } from "../../stores/ui/actions";
    import {
        convertToTflite,
        downloadTfliteModel,
    } from "../../stores/aggregatedActions";
    import { getTrainerADD } from "../../../stores/actions";
    let downloadOption = "arduino";
    let quantize = false;
    let isDownloading = false;
    let isConverting = false;
    let isbtnDisabled = false;

    let trainer;
    let isApplicationMode = false;
    async function handleConvert(quantize) {
        console.log("handleConvert");
        isConverting = true;
        trainer = await getTrainerADD();
        await convertToTflite(quantize, trainer);
        isConverting = false;
        alert("convert done");
    }

    //quantize 구현해야 됨.
    async function handleDownload() {
        isDownloading = true;
        await downloadTfliteModel(quantize);
        isDownloading = false;
    }
    onMount(async () => {
        trainer = await getTrainerADD();
        console.log("주소는 : ", trainer);
        if (trainer === "MOLE") {
            isApplicationMode = true;
        }
    });
    const strAsset = {
        btnconvert: "변환",
        btnSend: "전송",
        btnDownload: "다운로드",
        btnApp_one: "TinyML예제에서 체험",
        btnApp_two: "TinyML예제로 이동",
        finConvert: "변환이 완료되었습니다.",
        finSend: "전송이 완료되었습니다.",
    };
</script>

<TrainerConvert>
<div slot="convert-send">
    <div class="progress-container">
        <div class="btn-container">
            <button
                class="btn-convert btn-stroke"
                disabled={isConverting}
                on:click={() => {
                    handleConvert(false);
                }}>{strAsset.btnconvert}</button
            >
            <button class="btn-send btn-stroke" disabled
                >{strAsset.btnSend}</button
            >
            <button
                class="btn-download btn-stroke"
                on:click={() => handleDownload()}>{strAsset.btnDownload}</button
            >
        </div>
        <div class="myProgress">
            <div class="myBar"></div>
        </div>
    </div>
    <div class="move-page">
        {#if isApplicationMode}
        <Link to="/vision-experience">
            <button class="btn-app btn-fill" disabled={isbtnDisabled}>
                {#if isbtnDisabled}
                    <img src={icArrowBlack} alt="arrow" />
                {:else if !isbtnDisabled}
                    <img src={icArrowWhite} alt="arrow" />
                {/if}
                {strAsset.btnApp_one}
            </button>
        </Link>
    {:else if !isApplicationMode}
        <Link to="/visionApps-select">
            <button class="btn-app btn-fill" disabled={isbtnDisabled}>
                {#if isbtnDisabled}
                    <img src={icArrowBlack} alt="arrow" />
                {:else if !isbtnDisabled}
                    <img src={icArrowWhite} alt="arrow" />
                {/if}
                {strAsset.btnApp_two}
            </button>
        </Link>
    {/if}
    </div>
</div>
</TrainerConvert>

<style lang="scss">
    .btn-container {
        margin-bottom: 12px;
    }
    .btn-download,
    .btn-app {
        float: right;
        margin-left: auto;
    }
    .btn-convert {
        margin-right: 24px;
    }
    .progress-container {
        margin-bottom: 128px;
    }
    .fin-txt {
        color: deepskyblue;
        margin-left: 12px;
    }
    .btn-app {
        display: flex;
        margin-left: 12px;
    }
    img {
        margin-right: 12px;
    }
</style>