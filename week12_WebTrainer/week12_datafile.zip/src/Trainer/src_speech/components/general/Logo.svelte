<!--
Copyright 2021 Google LLC

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

/**
* @author Rikard Lindstrom <rlindstrom@google.com>
*/
-->
<script>
  export let width = 66;
  export let height = 72;
</script>

<svg
  {width}
  {height}
  viewBox="0 0 66 72"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  alt="Tiny Motion Trainer Logo"
>
  <g clip-path="url(#clip0)">
    <path
      d="M0.237527 17.5964L31.6612 0.0611718C31.9635 -0.10833 32.336 0.11585 32.336 0.465789V71.5417C32.336 71.8425 32.0607 72.0612 31.7746 71.9901L20.9671 69.4312C20.762 69.382 20.6162 69.196 20.6162 68.9773L20.6756 20.8224C20.6756 20.4615 20.2815 20.2374 19.9792 20.4287L0.788156 32.518C0.48585 32.7094 0.0917716 32.4907 0.0917716 32.1298L0 18.0065C0 17.837 0.0917716 17.6784 0.237527 17.5964Z"
      fill="#FF6F00"
    />
    <path
      d="M34.6677 2.8377L65.5731 19.7387C65.7243 19.8207 65.8214 19.9902 65.8107 20.1652L65.1089 37.4106C65.0927 37.7715 64.6986 37.9738 64.4017 37.777L48.0285 26.978C47.7262 26.7812 47.3268 26.9944 47.3214 27.3608L47.2566 31.6366C47.2566 31.8061 47.343 31.9592 47.4887 32.0467L52.3472 36.6396C52.4984 36.7271 52.5847 36.8966 52.5739 37.0716L51.9207 47.1597C51.8991 47.4659 51.6022 47.6682 51.3161 47.5643L46.8031 44.9343C46.5062 44.8304 46.1985 45.0546 46.1985 45.3717V65.7994C46.1985 65.9853 46.0905 66.1548 45.9178 66.2259L36.0712 70.4635C35.7743 70.5892 35.445 70.376 35.4342 70.0479L33.9983 3.25325C33.9875 2.89785 34.36 2.6682 34.6677 2.8377Z"
      fill="#FF6F00"
    />
    <path
      d="M64.9095 33.7309L46.4472 22.7844V31.5165M34.5115 1.27954L63.3979 17.9509V32.8288M46.4472 30.2862L54.8578 35.2455L54.9819 48.0894L46.4472 43.1301V61.9503L35.1485 68.5608V1.67869M20.5514 22.4782L3.30371 32.8288V17.9509L31.5478 1.67869V68.5608L20.2491 61.9503V22.2103"
      stroke="black"
      stroke-width="2.5"
      stroke-miterlimit="10"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </g>
  <defs>
    <clipPath id="clip0">
      <rect width="66" height="72" fill="white" />
    </clipPath>
  </defs>
</svg>
